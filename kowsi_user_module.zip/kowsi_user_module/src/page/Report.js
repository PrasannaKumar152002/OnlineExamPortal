// Report.js
import React from 'react';

const Report = () => {
  return (
    <div>
      <h2>Report Page</h2>
      {/* Add your report content here */}
    </div>
  );
};

export default Report;
