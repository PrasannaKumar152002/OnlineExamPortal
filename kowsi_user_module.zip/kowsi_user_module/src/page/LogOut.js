// Logout.js
import React from 'react';

const LogOut = () => {
  return (
    <div>
      <h2>Logout Page</h2>
      {/* Add your logout content here */}
    </div>
  );
};

export default LogOut;
