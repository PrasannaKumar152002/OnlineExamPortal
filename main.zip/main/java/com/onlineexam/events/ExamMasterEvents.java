package com.onlineexam.events;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilHttp;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.GenericServiceException;
import org.apache.ofbiz.service.LocalDispatcher;

import java.util.Date;
import java.util.List;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.onlineexam.forms.ExamMasterCheck;
import com.onlineexam.forms.HibernateValidationMaster;
import com.onlineexam.helper.HibernateHelper;

public class ExamMasterEvents {
    public static final String module = ExamMasterEvents.class.getName();

    public static String insertExamMasterEvent(HttpServletRequest request, HttpServletResponse response) {

        Locale locale = UtilHttp.getLocale(request);
        final String module = ExamMasterEvents.class.getName();
        String resource_error = "OnlineexamUiLabels";

        Delegator delegator = (Delegator) request.getAttribute("delegator");
        LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");

//        String examId = (String) request.getAttribute("examId");
        String examName = (String) request.getAttribute("examName");
        String description = (String) request.getAttribute("description");

        String creationDate = (String) request.getAttribute("creationDate");
        String expirationDate = (String) request.getAttribute("expirationDate");
        String noOfQuestions = (String) request.getAttribute("noOfQuestions");
        String durationMinutes = (String) request.getAttribute("durationMinutes");
        String passPercentage = (String) request.getAttribute("passPercentage");
        String questionsRandomized = (String) request.getAttribute("questionsRandomized");
        String answersMust = (String) request.getAttribute("answersMust");
        String enableNegativeMark = (String) request.getAttribute("enableNegativeMark");
        String negativeMarkValue = (String) request.getAttribute("negativeMarkValue");

        // Convert date strings to Timestamp
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
        Date creationDateObj = null;
        Date expirationDateObj = null;
        try {
            creationDateObj = sdf.parse(creationDate);
            expirationDateObj = sdf.parse(expirationDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        Timestamp cTimestamp = new Timestamp(creationDateObj.getTime());
        Timestamp eTimestamp = new Timestamp(expirationDateObj.getTime());
        
        System.out.println("********************************************\nCREATION DATE: " +  creationDate + "\tTTTT\t" + creationDateObj + "\tSSSS\t" + cTimestamp);

        Map<String, Object> examinfo = UtilMisc.toMap("examName", examName, "description",
                description, "creationDate", cTimestamp, "expirationDate", eTimestamp, "noOfQuestions",
                noOfQuestions, "durationMinutes", durationMinutes, "passPercentage", passPercentage,
                "questionsRandomized", questionsRandomized, "answersMust", answersMust, "enableNegativeMark",
                enableNegativeMark, "negativeMarkValue", negativeMarkValue);

        try {
            Debug.logInfo("=======Creating ExamMaster record in event using service InsertExamMasterService=========",
                    module);
            HibernateValidationMaster hibernate = HibernateHelper.populateBeanFromMap(examinfo,
                    HibernateValidationMaster.class);

            Set<ConstraintViolation<HibernateValidationMaster>> errors = HibernateHelper
                    .checkValidationErrors(hibernate, ExamMasterCheck.class);
            boolean hasFormErrors = HibernateHelper.validateFormSubmission(delegator, errors, request, locale,
                    "Mandatory Err Topic Master", resource_error, false);

            if (!hasFormErrors) {
                dispatcher.runSync("CreateExamMasterService", examinfo);
                request.setAttribute("_EVENT_MESSAGE_", "ExamMaster record inserted successfully.");
            }
        } catch (GenericServiceException e) {
            String errMsg = "Unable to create new records in ExamMaster entity: " + e.toString();
            request.setAttribute("_ERROR_MESSAGE_", errMsg);
            return "error";
        }

        return "success";
    }
    
    public static String fetchExamMasterEvent(HttpServletRequest request, HttpServletResponse response) {

		Locale locale = UtilHttp.getLocale(request);
		final String module = ExamMasterEvents.class.getName();
		String resource_error = "OnlineexamUiLabels";

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");

		try {
			List<GenericValue> list = EntityQuery.use(delegator).from("ExamMaster").queryList();
			request.setAttribute("ExamMaster", list);
			System.out.println(request.getAttribute("ExamMaster"));
		} catch (GenericEntityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "success";
	}
}
