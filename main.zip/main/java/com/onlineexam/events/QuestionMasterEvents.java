package com.onlineexam.events;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilHttp;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.GenericServiceException;
import org.apache.ofbiz.service.LocalDispatcher;

import com.onlineexam.forms.HibernateValidationMaster;
import com.onlineexam.forms.QuestionMasterCheck;
import com.onlineexam.helper.HibernateHelper;

public class QuestionMasterEvents {
	public static final String module = QuestionMasterEvents.class.getName();

	public static String insertQuestionMasterEvent(HttpServletRequest request, HttpServletResponse response) {

		Locale locale = UtilHttp.getLocale(request);
		final String module = QuestionMasterEvents.class.getName();
		String resource_error = "OnlineexamUiLabels";

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
//		GenericValue userLogin = (GenericValue) request.getSession().getAttribute("userLogin");

		String questionDetail = (String) request.getAttribute("questionDetail");
		String optionA = (String) request.getAttribute("optionA");
		String optionB = (String) request.getAttribute("optionB");
		String optionC = (String) request.getAttribute("optionC");
		String optionD = (String) request.getAttribute("optionD");
		String optionE = (String) request.getAttribute("optionE");
		String answer = (String) request.getAttribute("answer");
		String numAnswers = (String) request.getAttribute("numAnswers");
		String questionType = (String) request.getAttribute("questionType");
		String difficultyLevel = (String) request.getAttribute("difficultyLevel");
		String answerValue = (String) request.getAttribute("answerValue");
		String topicId = (String) request.getAttribute("topicId");
		String negativeMarkValue = (String) request.getAttribute("negativeMarkValue");

		Map<String, Object> mp = UtilMisc.toMap("questionDetail", questionDetail, "optionA", optionA, "optionB",
				optionB, "optionC", optionC, "optionD", optionD, "optionE", optionE, "answer", answer, "numAnswers",
				numAnswers, "questionType", questionType, "difficultyLevel", difficultyLevel, "answerValue",
				answerValue, "topicId", topicId, "negativeMarkValue", negativeMarkValue);

		try {
			Debug.logInfo(
					"=======Creating QuestionMaster record in event using service InsertQuestionMasterService=========",
					module);
			HibernateValidationMaster hibernate = HibernateHelper.populateBeanFromMap(mp,
					HibernateValidationMaster.class);
			System.out.println("I'm here-1");
			Set<ConstraintViolation<HibernateValidationMaster>> errors = HibernateHelper
					.checkValidationErrors(hibernate, QuestionMasterCheck.class);
			System.out.println("I'm here-2");
			boolean hasFormErrors = HibernateHelper.validateFormSubmission(delegator, errors, request, locale,
					"Mandatory Err Topic Master", resource_error, false);

			System.out.println("form-" + hasFormErrors);

			if (!hasFormErrors) {
				dispatcher.runSync("CreateQuestionMasterService",
						UtilMisc.toMap("questionDetail", questionDetail, "optionA", optionA, "optionB", optionB,
								"optionC", optionC, "optionD", optionD, "optionE", optionE, "answer", answer,
								"numAnswers", numAnswers, "questionType", questionType, "difficultyLevel",
								difficultyLevel, "answerValue", answerValue, "topicId", topicId, "negativeMarkValue",
								negativeMarkValue));
				request.setAttribute("_EVENT_MESSAGE_", "QuestionMaster record inserted succesfully.");
			}
		} catch (GenericServiceException e) {
			String errMsg = "Unable to create new records in QuestionMaster entity: " + e.toString();
			request.setAttribute("_ERROR_MESSAGE_", errMsg);
			return "error";
		}
		return "success";
	}
	
	public static String fetchQuestionMasterEvent(HttpServletRequest request, HttpServletResponse response) {

		Locale locale = UtilHttp.getLocale(request);
		final String module = QuestionMasterEvents.class.getName();
		String resource_error = "OnlineexamUiLabels";

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");

		try {
			List<GenericValue> list = EntityQuery.use(delegator).from("QuestionMaster").queryList();
			request.setAttribute("QuestionMaster", list);
			System.out.println(request.getAttribute("QuestionMaster"));
		} catch (GenericEntityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "success";
	}
}
