package com.onlineexam.events;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilHttp;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.GenericServiceException;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;

import com.onlineexam.forms.HibernateValidationMaster;
import com.onlineexam.forms.TopicMasterCheck;
import com.onlineexam.helper.HibernateHelper;

import java.util.List;

public class TopicMasterEvents {

	private static final String MODULE = TopicMasterEvents.class.getName();
	private static final String RES_ERR = "OnlineexamUiLabels";

	public static String createTopicMasterEvent(HttpServletRequest request, HttpServletResponse response) {

		Locale locale = UtilHttp.getLocale(request);

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
//		GenericValue userLogin = (GenericValue) request.getSession().getAttribute("userLogin");

//		String topicId = (String) request.getAttribute("topicId");
//		GenericValue ofbizDemo = delegator.makeValue("OfbizDemo");
//        // Auto generating next sequence of ofbizDemoId primary key
//        ofbizDemo.setNextSeqId();
		String topicName = (String) request.getAttribute("topicName");

//		if (UtilValidate.isEmpty(topicId) || UtilValidate.isEmpty(topicName)) {
//			String errMsg = "TopicId and TopicName are required fields on the form and can't be empty.";
//			request.setAttribute("_ERROR_MESSAGE_", errMsg);
//			return "error";
//		}

		Map<String, Object> mp = UtilMisc.toMap("topicName", topicName);

		try {
			Debug.logInfo("=======Creating TopicMaster record in event using service CreateTopicMasterService=========",
					MODULE);
			HibernateValidationMaster hibernate = HibernateHelper.populateBeanFromMap(mp,
					HibernateValidationMaster.class);

			Set<ConstraintViolation<HibernateValidationMaster>> errors = HibernateHelper
					.checkValidationErrors(hibernate, TopicMasterCheck.class);
			boolean hasFormErrors = HibernateHelper.validateFormSubmission(delegator, errors, request, locale,
					"Mandatory Err Topic Master", RES_ERR, false);

			if (!hasFormErrors) {
				try {
					Map<String, ? extends Object> createTopicMasterInfoResult = dispatcher.runSync(
							"CreateTopicMasterService", UtilMisc.<String, Object>toMap("topicName", topicName));
					ServiceUtil.getMessages(request, createTopicMasterInfoResult, null);
					if (ServiceUtil.isError(createTopicMasterInfoResult)) {
						String errorMessage = ServiceUtil.getErrorMessage(createTopicMasterInfoResult);
						request.setAttribute("_ERROR_MESSAGE_", errorMessage);
						Debug.logError(errorMessage, MODULE);
						return "error";
					} else {

						return "success";
					}
				} catch (GenericServiceException e) {
					String errMsg = "Error setting topics info: " + e.toString();
					request.setAttribute("_ERROR_MESSAGE_", errMsg);
					return "error";
				}
			} else {
				request.setAttribute("_ERROR_MESSAGE", errors);
				return "error";
			}
		} catch (Exception e) {
			Debug.logError(e, MODULE);
			request.setAttribute("_ERROR_MESSAGE", e);
			return "error";
		}
	}

	public static String fetchTopicMasterEvent(HttpServletRequest request, HttpServletResponse response) {

		Delegator delegator = (Delegator) request.getAttribute("delegator");

		try {
			List<GenericValue> list = EntityQuery.use(delegator).from("TopicMaster").queryList();
			request.setAttribute("TopicMaster", list);
			System.out.println(request.getAttribute("TopicMaster"));
		} catch (GenericEntityException e) {
			Debug.logError(e, MODULE);
			request.setAttribute("_ERROR_MESSAGE", e);
			return "error";
		}
		return "success";
	}
}
