package com.onlineexam.events;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;

import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilHttp;
import org.apache.ofbiz.base.util.UtilMisc;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.GenericServiceException;
import org.apache.ofbiz.service.LocalDispatcher;

import com.onlineexam.forms.HibernateValidationMaster;
import com.onlineexam.forms.ExamTopicMappingCheck;
import com.onlineexam.helper.HibernateHelper;

public class ExamTopicMappingEvents {
	public static final String module = ExamTopicMappingEvents.class.getName();

	public static String insertExamTopicMappingEvent(HttpServletRequest request, HttpServletResponse response) {

		Locale locale = UtilHttp.getLocale(request);
		final String module = ExamTopicMappingEvents.class.getName();
		String resource_error = "OnlineexamUiLabels";

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
//		GenericValue userLogin = (GenericValue) request.getSession().getAttribute("userLogin");

		String examId = (String) request.getAttribute("examId");
//		GenericValue ofbizDemo = delegator.makeValue("OfbizDemo");
//        // Auto generating next sequence of ofbizDemoId primary key
//        ofbizDemo.setNextSeqId();
		String topicId = (String) request.getAttribute("topicId");
		String percentage = (String) request.getAttribute("percentage");
		String topicPassPercentage = (String) request.getAttribute("topicPassPercentage");
		String questionsPerExam = (String) request.getAttribute("questionsPerExam");

//		if (UtilValidate.isEmpty(topicId) || UtilValidate.isEmpty(topicName)) {
//			String errMsg = "TopicId and TopicName are required fields on the form and can't be empty.";
//			request.setAttribute("_ERROR_MESSAGE_", errMsg);
//			return "error";
//		}

		Map<String, Object> mp = UtilMisc.toMap("examId", examId, "topicId", topicId, "percentage", percentage,
				"topicPassPercentage", topicPassPercentage, "questionsPerExam", questionsPerExam);

		try {
			Debug.logInfo("=======Creating ExamTopicMapping record in event using service InsertExamTopicMappingMasterService=========",
					module);
			HibernateValidationMaster hibernate = HibernateHelper.populateBeanFromMap(mp,
					HibernateValidationMaster.class);
			System.out.println("I'm here-1");
			Set<ConstraintViolation<HibernateValidationMaster>> errors = HibernateHelper
					.checkValidationErrors(hibernate, ExamTopicMappingCheck.class);
			System.out.println("I'm here-2");
			boolean hasFormErrors = HibernateHelper.validateFormSubmission(delegator, errors, request, locale,
					"Mandatory Err Topic Master", resource_error, false);

			System.out.println("form-" + hasFormErrors);

			if (!hasFormErrors) {
				dispatcher.runSync("CreateExamTopicMappingMasterService",
						UtilMisc.toMap("examId", examId, "topicId", topicId, "percentage", percentage,
								"topicPassPercentage", topicPassPercentage, "questionsPerExam", questionsPerExam));
				request.setAttribute("_EVENT_MESSAGE_", "ExamTopicMapping record inserted succesfully.");
			}
		} catch (GenericServiceException e) {
			String errMsg = "Unable to create new records in ExamTopicMapping entity: " + e.toString();
			request.setAttribute("_ERROR_MESSAGE_", errMsg);
			return "error";
		}
		return "success";
	}
	
	public static String fetchExamTopicMappingEvent(HttpServletRequest request, HttpServletResponse response) {

		Locale locale = UtilHttp.getLocale(request);
		final String module = TopicMasterEvents.class.getName();
		String resource_error = "OnlineexamUiLabels";

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");

		try {
			List<GenericValue> list = EntityQuery.use(delegator).from("ExamTopicMapping").queryList();
			request.setAttribute("ExamTopicMapping", list);
			System.out.println(request.getAttribute("ExamTopicMapping"));
		} catch (GenericEntityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "success";
	}
}
