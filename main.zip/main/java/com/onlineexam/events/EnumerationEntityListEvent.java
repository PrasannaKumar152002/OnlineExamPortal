package com.onlineexam.events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;

import com.onlineexam.constantvalue.ConstantValues;

public class EnumerationEntityListEvent {
	
	public static String listOfEnumerationEntity(HttpServletRequest request, HttpServletResponse response) {

		Delegator delegator = (Delegator) request.getAttribute("delegator");
		List<Map<String, Object>> enumerationdata = new ArrayList<Map<String, Object>>();
		try {
			List<GenericValue> listOfEnumerationData = EntityQuery.use(delegator).from("Enumeration")
					.where(ConstantValues.ENUM_TYPE_ID, "Q_TYPE").cache().queryList();
			if (UtilValidate.isNotEmpty(listOfEnumerationData)) {
				for (GenericValue list : listOfEnumerationData) {
					Map<String, Object> listOfEnumerationEntity = new HashMap<String, Object>();
					listOfEnumerationEntity.put(ConstantValues.ENUM_ID, list.get(ConstantValues.ENUM_ID));
					listOfEnumerationEntity.put(ConstantValues.SEQUENCE_ID, list.get(ConstantValues.SEQUENCE_ID));
					listOfEnumerationEntity.put(ConstantValues.ENUM_TYPE_ID, list.get(ConstantValues.ENUM_TYPE_ID));
					listOfEnumerationEntity.put(ConstantValues.DESCRIPTION, list.get(ConstantValues.DESCRIPTION));
					enumerationdata.add(listOfEnumerationEntity);
				}
			}
			else
			{
				
			}
			request.setAttribute("EnumerationData", enumerationdata);
			return "Success";
		} catch (GenericEntityException e) {
			request.setAttribute("Error", e);
			return "error";
		}
	}
}
