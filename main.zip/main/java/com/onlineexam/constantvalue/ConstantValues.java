package com.onlineexam.constantvalue;

public class ConstantValues {
private static final String ENUM_ID = "enumId";
private static final String SEQUENCE_ID = "sequenceId";
private static final String ENUM_TYPE_ID = "enumTypeId";
private static final String TOPIC_ID = "topicId";
private static final String TOPIC_NAME = "topicName";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
//private static final String DESCRIPTION = "description";
}
